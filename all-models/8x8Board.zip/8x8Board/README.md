I need one print for each STL file. There are a total of four STL files. Each of them is 1/4 of the chess board.
LL stands for Lower Left
LR stands for Lower Right
UL stands for Upper Left
UR stands for Upper Right